package com.example.NoSQL;

import java.util.List;
import java.util.stream.Stream;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface DbServices extends MongoRepository<Employee,Integer>{
	public Employee findByName(String name);
	public Employee findByNameAndAge(String name,int age);
	public void deleteByName(String name);
	public List<Employee> findByAgeGreaterThan(int age);
	/*@Query("{'age':x}")
	List<String> getName(Long x);*/
}
