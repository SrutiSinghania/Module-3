package com.example.NoSQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoSqlApplication.class, args);
	}
}
