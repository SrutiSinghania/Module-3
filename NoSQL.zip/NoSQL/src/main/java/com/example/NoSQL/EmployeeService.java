package com.example.NoSQL;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class EmployeeService 
{
	
	@Autowired 
	DbServices service;
	
	@PostMapping("/insert")
	public String insertEmployee(@RequestBody Employee e)
	{
		service.save(e);
		return "Success";
	}
	@GetMapping(value= "/retreive")//,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Employee> displayEmployee()
	{
		//System.out.println(service.getName(12l));
		
		return service.findAll();
	}
	@GetMapping(value= "/ret/{id}")//,produces=MediaType.APPLICATION_JSON_VALUE)
	public Optional<Employee> displayEmployeeById(@PathVariable("id") int id)
	{
		return service.findById(id);
	}
	@GetMapping(value="/selByName/{name}")//,produces=MediaType.APPLICATION_JSON_VALUE)
	//@RequestMapping(path="/select",method=RequestMethod.GET,produces=MediaType.APPLICATION_XML_VALUE)
	public Employee readByName( @PathVariable("name") String name)
	{
		Employee emp=service.findByName(name);
		return emp;
	}
	@GetMapping(value="/selByNameAndAge/{name}/{age}")//,produces=MediaType.APPLICATION_JSON_VALUE)
	//@RequestMapping(path="/select",method=RequestMethod.GET,produces=MediaType.APPLICATION_XML_VALUE)
	public Employee readByNameAndAge( @PathVariable("name") String name,@PathVariable("age") int age)
	{
		Employee emp=service.findByNameAndAge(name,age);
		return emp;
	}
	@GetMapping(value="/deleteById/{id}")//,produces=MediaType.APPLICATION_JSON_VALUE)
	//@RequestMapping(path="/select",method=RequestMethod.GET,produces=MediaType.APPLICATION_XML_VALUE)
	public void deleteById(@PathVariable("id") int age)
	{
		service.deleteById(age);
	}
	@PutMapping(value="/update/{id}/{name}/{salary}")
	public int updateEmployee(@PathVariable("id") int id,@PathVariable("name")String name,@PathVariable("salary") int salary)
	{
		Optional<Employee> emp=service.findById(id);
		if(emp.isPresent())
		{
			Employee e=emp.get();
			e.setName(name);
			e.setAge(id);
			e.setSalary(salary);
			service.save(e);
			return id;
		}
		return -1;
	}
	@PostMapping("/insertAll")
	public String insertEmployees(@RequestBody List<Employee> elist)
	{
		service.saveAll(elist);
		return "Success";
	}
	@GetMapping(value="/deleteByName/{Name}")//,produces=MediaType.APPLICATION_JSON_VALUE)
	//@RequestMapping(path="/select",method=RequestMethod.GET,produces=MediaType.APPLICATION_XML_VALUE)
	public void deleteName(@PathVariable("Name") String name)
	{
		service.deleteByName(name);
	}
	@GetMapping(value="/selByAgeOnCon/{age}")//,produces=MediaType.APPLICATION_JSON_VALUE)
	//@RequestMapping(path="/select",method=RequestMethod.GET,produces=MediaType.APPLICATION_XML_VALUE)
	public List<Employee> readByName( @PathVariable("age") int age)
	{
		return service.findByAgeGreaterThan(age);
	}
}
